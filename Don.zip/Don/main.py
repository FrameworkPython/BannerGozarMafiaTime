import asyncio
import logging
import re
import heapq
from collections import defaultdict
from operator import itemgetter
from datetime import datetime, timedelta
import uvloop
import jdatetime
from rubpy import Client, filters

LOG_FORMAT = "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s"
DATE_FORMAT = "%Y-%m-%d %H:%M:%S"
console_handler = logging.StreamHandler()
console_handler.setLevel(logging.INFO)
console_handler.setFormatter(
    logging.Formatter(LOG_FORMAT, datefmt=DATE_FORMAT)
)
logger = logging.getLogger("DonitoBot")
logger.setLevel(logging.INFO)
logger.addHandler(console_handler)
logger.propagate = False

TARGET_GROUP_GUID = "g0DHpOn042b93c4982b5b135365c7bb6"
MAIN_GROUP_GUID = "g0E19S900dd50643ab8fcbf23dad9e70"
MAIN_ADMIN_GUID = "u0JNjam04cd438e3013ebd0111bc3fb3"
ADMIN_GUIDS = {MAIN_ADMIN_GUID}
IS_BOT_ACTIVE = True
WARNING_AFTER_HOURS = 5
AUTO_CLOSE_AFTER_HOURS = 6
FORWARD_RETRY_DELAY = 10
PENDING_EXPIRE_SECONDS = 300
PROCESSED_CACHE_LIMIT = 10000
FORWARD_WORKERS = 2
MAIN_GROUP_FILTER = filters.object_guids([MAIN_GROUP_GUID])

CONFIRM_WORDS = {
    "بله",
    "آره",
    "اوکی",
    "تایید",
    "تائید",
    "باشه",
    "✅",
    "✓",
}
REJECT_WORDS = {
    "نه",
    "خیر",
    "رد",
    "لغو",
    "❌",
    "✗",
}
STATS_WORDS = {
    "آمار",
    "stats",
    "امار",
    "احصائیه",
    "وضعیت",
}
HELP_WORDS = {
    "راهنما",
    "help",
    "کمک",
    "راهنمایی",
    "راهنمايي",
}
DUNYTO_VARIATIONS = {
    "دنیتو",
    "دونیتو",
    "دُنیتو",
}

NAME_MAP = {
    "فایتر": "Fighter",
    "اهورا": "Ahoora",
    "سبحان": "Geshtapo",
    "یحیی": "Yahya",
    "صبحان": "Geshtapo",
    "یکتا": "Yekta",
    "ساره": "Sareh",
    "مجی": "Moji",
    "گاد فادر": "GodFather",
    "گادفادر": "GodFather",
    "فرید": "Farid",
    "هانتر": "Hunter",
    "هانی": "Hani",
    "ماتادور": "Matador",
    "نیلوفر": "Niloofar",
    "هانیه": "Hanieh",
    "رضا": "Reza",
    "آتنا": "Atena",
    "اتنا": "Atena",
}

PERSIAN_TO_FINGLISH_MAP = {
    "ا": "a",
    "آ": "a",
    "ب": "b",
    "پ": "p",
    "ت": "t",
    "ث": "s",
    "ج": "j",
    "چ": "ch",
    "ح": "h",
    "خ": "kh",
    "د": "d",
    "ذ": "z",
    "ر": "r",
    "ز": "z",
    "ژ": "zh",
    "س": "s",
    "ش": "sh",
    "ص": "s",
    "ض": "z",
    "ط": "t",
    "ظ": "z",
    "ع": "a",
    "غ": "gh",
    "ف": "f",
    "ق": "gh",
    "ک": "k",
    "ك": "k",
    "گ": "g",
    "ل": "l",
    "م": "m",
    "ن": "n",
    "و": "oo",
    "ه": "h",
    "ی": "i",
    "ي": "i",
    "ئ": "e",
    "؟": "?",
    "،": ",",
    "؛": ";",
    "۰": "0",
    "۱": "1",
    "۲": "2",
    "۳": "3",
    "۴": "4",
    "۵": "5",
    "۶": "6",
    "۷": "7",
    "۸": "8",
    "۹": "9",
    "َ": "a",
    "ُ": "o",
    "ِ": "e",
    "\u200c": None,
}
FINGLISH_TABLE = str.maketrans(
    {ord(key): value for key, value in PERSIAN_TO_FINGLISH_MAP.items()}
)
NORMALIZE_TABLE = str.maketrans(
    {8204: " ", 1610: "ی", 1603: "ک"}
)
DIGIT_TABLE = str.maketrans(
    {
        ord("۰"): "0",
        ord("۱"): "1",
        ord("۲"): "2",
        ord("۳"): "3",
        ord("۴"): "4",
        ord("۵"): "5",
        ord("۶"): "6",
        ord("۷"): "7",
        ord("۸"): "8",
        ord("۹"): "9",
    }
)

NAME_BY_LEN = {}
for name, mapped in NAME_MAP.items():
    NAME_BY_LEN.setdefault(len(name), []).append((name, mapped))

START_REGEX = re.compile(
    r"^(?!پایان[\s,،])([^,،]+)[,،]\s*([^,،]+?)"
    r"(?:\s*[,،]\s*(فور))?\s*$"
)
END_REGEX = re.compile(
    r"^پایان[\s,،]+(.+?)(?:\s*[,،]?\s*(فور))?\s*$"
)
STOP_REGEX = re.compile(r"^!stop$")
BOT_START_REGEX = re.compile(r"^!start$")
LIST_GAMES_REGEX = re.compile(
    r"^(?:(?:لیست|نمایش)\s+)?بازی(?:\s*ها)?$"
)
DELETE_GAME_REGEX = re.compile(
    r"^(?:حذف|پاک)(?:\s+کردن)?\s+بازی\s+(\d+)$"
)
DELETE_ALL_REGEX = re.compile(
    r"^(?:حذف|پاک)(?:\s+کردن)?"
    r"(?:\s+(?:تمام|همه|کل|کلیه|تمامی))?"
    r"\s+بازی(?:\s*ها)?$"
)
AUTO_STATS_SET_REGEX = re.compile(
    r"^(?:آمار|احصائیه)\s+(?:خودکار|اتوماتیک)\s+"
    r"(?:در\s+)?ساعت\s+(\d{1,2}:\d{2})$"
)
AUTO_STATS_DISABLE_REGEX = re.compile(
    r"^(?:لغو|حذف|غیرفعال|قطع)\s+"
    r"(?:(?:آمار\s+(?:خودکار|اتوماتیک))|"
    r"(?:(?:خودکار|اتوماتیک)\s+آمار))$"
)
CLOSE_GROUP_REGEX = re.compile(
    r"^(?:بستن|بسته|قفل)(?:\s+کردن)?"
    r"(?:\s+(?:گروه|چت|گپ))?$"
)
OPEN_GROUP_REGEX = re.compile(
    r"^(?:باز\s*کردن|وا\s*کردن|آزاد\s*کردن)"
    r"(?:\s+(?:گروه|چت|گپ))?$"
)
ADD_ADMIN_REGEX = re.compile(
    r"^(?:ادمین\s+کن|افزودن\s+ادمین|ادمین\s+کردن|"
    r"ادمین\s+اضافه\s+کن)(?:\s+(\S+))?$"
)
REMOVE_ADMIN_REGEX = re.compile(
    r"^(?:عزل\s+ادمین|حذف\s+ادمین|برداشتن\s+ادمین|"
    r"عزل\s+کردن)(?:\s+(\S+))?$"
)
DELETE_MESSAGES_REGEX = re.compile(
    r"^(?:حذف|پاک)(?:\s+کردن)?\s+پیام\s+(\d+)$"
)
BAN_REGEX = re.compile(
    r"^(?:بن(?:\s+کن)?|اخراج(?:\s+کن)?|حذف(?:\s+کن)?)"
    r"(?:\s+(\S+))?$"
)
UNBAN_REGEX = re.compile(
    r"^(?:آنبن(?:\s+کن)?|لغو\s+بن|لغو\s+اخراج|برگردان|"
    r"لغو\s+کردن|لغو)(?:\s+(\S+))?$"
)
BLOCK_REGEX = re.compile(
    r"^(?:بلاک|مسدود)(?:\s+کردن)?(?:\s+(\S+))?$"
)
SPECIAL_REGEX = re.compile(
    r"^(?:ویژه|مخصوص|خاص)(?:\s+(\S+))?$"
)
OBJECT_ID_REGEX = re.compile(r"^[ugc]\w+$")

HELP_TEXT = (
    "📖 راهنمای کامل ربات بنرگذار دُنیتو\n\n"
    "🎮 شروع بازی (کاربران ویژه)\n"
    "• یک عکس با کپشن زیر بفرستید:\n"
    "  [سناریو] ، [سازنده] ، فور\n"
    "• «فور» اختیاری است (فوروارد به گروه رسمی).\n"
    "• اگر «دنیتو» در سناریو باشد، خودکار به کپشن اضافه می‌شود.\n"
    "• مثال: مذاکره دنیتو ، هانتر ، فور\n\n"
    "✅ تأیید / ❌ رد بنر\n"
    "• بعد از ارسال عکس، پیش‌نمایشی دریافت می‌کنید.\n"
    "• با ریپلای روی پیش‌نمایش یکی از کلمات زیر را بفرستید:\n"
    "  تأیید: بله / آره / اوکی / تایید\n"
    "  رد: نه / خیر / رد / لغو\n"
    "• فقط سازندۀ اصلی می‌تواند تأیید/رد کند.\n\n"
    "🏁 پایان بازی\n"
    "• یک عکس با کپشن زیر بفرستید:\n"
    "  پایان [برنده] ، فور\n"
    "• «فور» اختیاری است.\n"
    "• در صورت وجود چند بازی، قدیمی‌ترین بسته می‌شود.\n"
    "• می‌توانید روی بنر شروع ریپلای بزنید.\n\n"
    "📊 آمار و اطلاعات\n"
    "• آمار: آمار / stats\n"
    "• راهنما: راهنما / help\n"
    "• لیست بازی‌های فعال: لیست بازی‌ها / نمایش بازی‌ها\n"
    "• حذف یک بازی: حذف بازی 01 / پاک بازی 01\n"
    "• حذف تمام بازی‌ها: حذف تمام بازی‌ها / پاک کل بازی‌ها\n\n"
    "👑 دستورات مدیریت گروه (ادمین‌ها)\n"
    "• قفل گروه: قفل / قفل گروه / بستن\n"
    "• باز کردن گروه: بازکردن / باز کردن گروه / وا کردن\n\n"
    "🔨 مدیریت کاربران (ادمین‌ها)\n"
    "• ویژه کردن: ویژه / ویژه u0xxx\n"
    "• بلاک کردن: بلاک / بلاک u0xxx / مسدود\n"
    "• بن کردن: بن / اخراج / حذف کن\n"
    "• آنبن + ارسال لینک: آنبن / برگردان / لغو بن\n\n"
    "⚙️ مدیریت ادمین‌ها (فقط ادمین اصلی)\n"
    "• افزودن ادمین: ادمین کن / افزودن ادمین u0xxx\n"
    "• حذف ادمین: عزل ادمین / حذف ادمین\n\n"
    "🧹 پاکسازی پیام‌ها (ادمین‌ها)\n"
    "• حذف پیام 20\n"
    "  حداکثر ۱۰۰۰ پیام آخر حذف می‌شود.\n\n"
    "⏰ آمار خودکار (ادمین‌ها)\n"
    "• تنظیم: آمار خودکار ساعت 00:00\n"
    "• لغو: لغو آمار خودکار / حذف آمار خودکار\n\n"
    "🛑 توقف و راه‌اندازی ربات (فقط ادمین اصلی)\n"
    "• توقف: !stop\n"
    "• راه‌اندازی: !start\n"
)

active_games = {}
pending_banners = {}
pending_by_preview = {}
start_message_index = {}
processing_previews = set()
processed_message_ids = {}
BACKGROUND_TASKS = set()
game_stats = {
    "total_games": 0,
    "builder_stats": defaultdict(int),
    "scenario_stats": defaultdict(int),
    "daily_games": 0,
    "last_reset": "",
}
BLOCKED_USERS = set()
SPECIAL_USERS = set()
AUTO_STATS_ENABLED = False
AUTO_STATS_TIME = None
AUTO_STATS_HANDLE = None
LAST_AUTO_STATS_DATE = ""
FORWARD_QUEUE = None
ACTIVE_EVENT = None
WORKERS = []
bot = Client("bot")


def log_error(context, error):
    logger.error(
        "%s | %s: %s", context, type(error).__name__, error
    )


def normalize_text(text):
    return text.translate(NORMALIZE_TABLE).strip().lower()


def first_word(text):
    if not text:
        return ""
    return text.split(maxsplit=1)[0].strip(".,!?؟،؛:()")


def consume_message_id(message_id):
    cache = processed_message_ids
    if message_id in cache:
        return False
    if len(cache) >= PROCESSED_CACHE_LIMIT:
        cache.popitem(last=False)
    cache[message_id] = None
    return True


def _task_done(task):
    BACKGROUND_TASKS.discard(task)
    if not task.cancelled():
        error = task.exception()
        if error is not None:
            logger.error("Background task error: %s", error)


def spawn(coro):
    task = asyncio.create_task(coro)
    BACKGROUND_TASKS.add(task)
    task.add_done_callback(_task_done)
    return task


def _silent_done(task):
    if not task.cancelled():
        task.exception()


async def delete_messages_safe(object_guid, message_ids):
    ids = [mid for mid in message_ids if mid is not None]
    if not ids:
        return
    try:
        await bot.delete_messages(
            object_guid=object_guid, message_ids=ids
        )
    except Exception as error:
        logger.warning("delete_messages failed: %s", error)


async def send_message_safe(
    object_guid, text, reply_to_message_id=None, auto_delete=None
):
    kwargs = {"object_guid": object_guid, "text": text}
    if reply_to_message_id is not None:
        kwargs["reply_to_message_id"] = reply_to_message_id
    if auto_delete is not None:
        kwargs["auto_delete"] = auto_delete
    try:
        await bot.send_message(**kwargs)
    except Exception as error:
        logger.warning("send_message failed: %s", error)


async def respond_and_cleanup(update, text, auto_delete=15):
    await send_message_safe(
        update.object_guid, text, update.message_id, auto_delete
    )
    await delete_messages_safe(
        update.object_guid, [update.message_id]
    )


def get_shamsi_now():
    return jdatetime.datetime.now().strftime("%Y/%m/%d - %H:%M")


def get_shamsi_date():
    return jdatetime.datetime.now().strftime("%Y/%m/%d")


def persian_to_finglish(text):
    return text.translate(FINGLISH_TABLE).title().replace(" ", "")


def one_edit_match(a, b):
    len_a = len(a)
    len_b = len(b)
    if len_a == len_b:
        diff = 0
        for index in range(len_a):
            if a[index] != b[index]:
                diff += 1
                if diff > 1:
                    return False
        return True
    if len_a + 1 == len_b:
        a, b = b, a
        len_a, len_b = len_b, len_a
    elif len_b + 1 != len_a:
        return False
    index_a = index_b = diff = 0
    while index_a < len_a and index_b < len_b:
        if a[index_a] != b[index_b]:
            diff += 1
            if diff > 1:
                return False
            index_a += 1
        else:
            index_a += 1
            index_b += 1
    return True


def normalize_builder_name(raw):
    key = " ".join(raw.translate(NORMALIZE_TABLE).split())
    mapped = NAME_MAP.get(key)
    if mapped is not None:
        return mapped, None
    length = len(key)
    for candidates in (
        NAME_BY_LEN.get(length),
        NAME_BY_LEN.get(length - 1),
        NAME_BY_LEN.get(length + 1),
    ):
        if not candidates:
            continue
        for name, mapped_name in candidates:
            if one_edit_match(key, name):
                return mapped_name, name
    return persian_to_finglish(key), None


def extract_message_id(result):
    if result is None:
        return None
    if isinstance(result, (list, tuple)):
        result = result[0] if result else None
    if result is None:
        return None
    if isinstance(result, int):
        return result
    if isinstance(result, str):
        return int(result) if result.isdigit() else None
    value = getattr(result, "message_id", None)
    if value is None:
        value = getattr(result, "message_ids", None)
    if value is None and isinstance(result, dict):
        value = result.get("message_id") or result.get("message_ids")
    if isinstance(value, (list, tuple)):
        value = value[0] if value else None
    if isinstance(value, dict):
        value = value.get("message_id") or value.get("id")
    if isinstance(value, int):
        return value
    if isinstance(value, str) and value.isdigit():
        return int(value)
    return value


def extract_message_ids(result):
    if result is None:
        return []
    messages = getattr(result, "messages", None)
    if messages is None:
        if isinstance(result, dict):
            messages = result.get("messages")
        elif isinstance(result, list):
            messages = result
    if not messages:
        return []
    ids = []
    for message in messages:
        if isinstance(message, int):
            ids.append(message)
            continue
        if isinstance(message, dict):
            message_id = message.get("message_id")
        else:
            message_id = getattr(message, "message_id", None)
        if message_id:
            ids.append(message_id)
    return ids


def find_available_game_id(games):
    for index in range(1, 100):
        game_id = f"{index:02d}"
        if game_id not in games:
            return game_id
    return "XX"


def is_user_allowed(update):
    author = update.author_guid
    if author in ADMIN_GUIDS:
        return True
    if not IS_BOT_ACTIVE or author in BLOCKED_USERS:
        return False
    return not SPECIAL_USERS or author in SPECIAL_USERS


def update_stats(builder, scenario):
    today = get_shamsi_date()
    if game_stats["last_reset"] != today:
        game_stats["daily_games"] = 0
        game_stats["last_reset"] = today
    game_stats["total_games"] += 1
    game_stats["daily_games"] += 1
    game_stats["builder_stats"][builder] += 1
    game_stats["scenario_stats"][scenario] += 1


def generate_stats_text():
    today = get_shamsi_date()
    daily_games = (
        game_stats["daily_games"]
        if game_stats["last_reset"] == today
        else 0
    )
    total_games = game_stats["total_games"]
    top_builders = heapq.nlargest(
        3, game_stats["builder_stats"].items(), key=itemgetter(1)
    )
    top_scenarios = heapq.nlargest(
        3, game_stats["scenario_stats"].items(), key=itemgetter(1)
    )
    builder_lines = "\n".join(
        f"{index}. {name}: {count} بازی"
        for index, (name, count) in enumerate(top_builders, 1)
    ) or "📭 داده‌ای موجود نیست"
    scenario_lines = "\n".join(
        f"{index}. {name}: {count} بازی"
        for index, (name, count) in enumerate(top_scenarios, 1)
    ) or "📭 داده‌ای موجود نیست"
    return (
        "📊 آمار ربات دُنیتو\n\n"
        f"📅 تاریخ: {today}\n"
        f"🎮 کل بازی‌های برگزار شده: {total_games}\n"
        f"📈 بازی‌های امروز: {daily_games}\n\n"
        f"🥇 ۳ سازنده برتر:\n{builder_lines}\n\n"
        f"🎭 ۳ سناریوی محبوب:\n{scenario_lines}"
    )


def set_bot_active(value):
    global IS_BOT_ACTIVE
    IS_BOT_ACTIVE = value
    if ACTIVE_EVENT is not None:
        if value:
            ACTIVE_EVENT.set()
        else:
            ACTIVE_EVENT.clear()


async def forward_worker():
    global FORWARD_QUEUE, ACTIVE_EVENT
    if FORWARD_QUEUE is None:
        FORWARD_QUEUE = asyncio.Queue()
    if ACTIVE_EVENT is None:
        ACTIVE_EVENT = asyncio.Event()
        if IS_BOT_ACTIVE:
            ACTIVE_EVENT.set()
    queue = FORWARD_QUEUE
    while True:
        task = await queue.get()
        try:
            if not IS_BOT_ACTIVE:
                await ACTIVE_EVENT.wait()
            try:
                result = await asyncio.wait_for(
                    bot.forward_messages(
                        from_object_guid=task["from_guid"],
                        message_ids=[task["message_id"]],
                        to_object_guid=TARGET_GROUP_GUID,
                    ),
                    timeout=30,
                )
                forwarded = extract_message_id(result)
                chat_id = task.get("chat_id")
                game_id = task.get("game_id")
                if chat_id and game_id and forwarded is not None:
                    games = active_games.get(chat_id)
                    if games:
                        game = games.get(game_id)
                        if game is not None:
                            game["forwarded_msg_id"] = forwarded
            except Exception as error:
                log_error("forward_queue", error)
                retries = task.get("retries", 0) + 1
                if retries < 3:
                    task["retries"] = retries
                    loop = asyncio.get_running_loop()
                    loop.call_later(
                        FORWARD_RETRY_DELAY,
                        get_forward_queue().put_nowait,
                        task,
                    )
        finally:
            queue.task_done()


def ensure_forward_workers():
    if WORKERS and not all(worker.done() for worker in WORKERS):
        return
    WORKERS.clear()
    for _ in range(FORWARD_WORKERS):
        WORKERS.append(asyncio.create_task(forward_worker()))


def get_forward_queue():
    global FORWARD_QUEUE
    if FORWARD_QUEUE is None:
        FORWARD_QUEUE = asyncio.Queue()
    ensure_forward_workers()
    return FORWARD_QUEUE


def cancel_game_timers(game):
    for key in ("warn_handle", "close_handle"):
        handle = game.pop(key, None)
        if handle is not None:
            handle.cancel()


async def send_game_timeout_warning(chat_id, game, hours):
    text = (
        "⚠️ هشدار زمان بازی\n\n"
        f"بازی شماره `{game['id']}`\n"
        f"سناریو: {game['scenario_caption']}\n"
        f"مدت زمان: {hours:.1f} ساعت\n\n"
        "لطفاً نسبت به پایان بازی اقدام کنید."
    )
    await send_message_safe(
        chat_id, text, game.get("start_msg_id"), 60
    )


async def close_expired_game(chat_id, game):
    games = active_games.get(chat_id)
    if not games:
        return
    removed = games.pop(game["id"], None)
    if removed is None:
        return
    cancel_game_timers(removed)
    if not games:
        active_games.pop(chat_id, None)
    start_message_index.pop(removed.get("start_msg_id"), None)
    await delete_messages_safe(
        chat_id, [removed.get("start_msg_id")]
    )
    forwarded = removed.get("forwarded_msg_id")
    if forwarded is not None:
        await delete_messages_safe(TARGET_GROUP_GUID, [forwarded])


def _game_warning(chat_id, game_id):
    games = active_games.get(chat_id)
    if not games:
        return
    game = games.get(game_id)
    if game is None or game.get("timeout_warned"):
        return
    game["timeout_warned"] = True
    spawn(
        send_game_timeout_warning(
            chat_id, game, WARNING_AFTER_HOURS
        )
    )


def _game_close(chat_id, game_id):
    games = active_games.get(chat_id)
    if not games:
        return
    game = games.get(game_id)
    if game is None or game.get("closing"):
        return
    game["closing"] = True
    spawn(close_expired_game(chat_id, game))


def schedule_auto_stats():
    global AUTO_STATS_HANDLE
    if not AUTO_STATS_ENABLED or not AUTO_STATS_TIME:
        return
    now = datetime.now()
    try:
        hour, minute = map(int, AUTO_STATS_TIME.split(":"))
        target = now.replace(
            hour=hour, minute=minute, second=0, microsecond=0
        )
    except ValueError:
        return
    if target <= now:
        target += timedelta(days=1)
    delay = (target - now).total_seconds()
    AUTO_STATS_HANDLE = asyncio.get_running_loop().call_later(
        delay, auto_stats_fire
    )


def auto_stats_fire():
    global LAST_AUTO_STATS_DATE, AUTO_STATS_HANDLE
    if not AUTO_STATS_ENABLED:
        return
    now = datetime.now()
    current_time = now.strftime("%H:%M")
    if current_time != AUTO_STATS_TIME:
        schedule_auto_stats()
        return
    today = jdatetime.datetime.now().strftime("%Y/%m/%d")
    if today == LAST_AUTO_STATS_DATE:
        schedule_auto_stats()
        return
    if IS_BOT_ACTIVE:
        LAST_AUTO_STATS_DATE = today
        spawn(
            send_message_safe(
                MAIN_GROUP_GUID, generate_stats_text()
            )
        )
        schedule_auto_stats()
        return
    AUTO_STATS_HANDLE = asyncio.get_running_loop().call_later(
        10, auto_stats_fire
    )


def expire_pending(user_guid, preview_msg_id):
    if preview_msg_id in processing_previews:
        return
    banner = pending_banners.get(user_guid)
    if banner is None:
        return
    if banner.get("preview_msg_id") != preview_msg_id:
        return
    pending_banners.pop(user_guid, None)
    pending_by_preview.pop(preview_msg_id, None)
    task = banner.get("download_task")
    if task is not None and not task.done():
        task.cancel()
    spawn(delete_messages_safe(banner["chat_id"], [preview_msg_id]))


async def resolve_target_guid(identifier):
    identifier = identifier.strip()
    if OBJECT_ID_REGEX.match(identifier):
        return identifier
    if identifier.startswith("@"):
        identifier = identifier[1:]
    if identifier.startswith("https://rubika.ir/join"):
        try:
            if "/joinc" in identifier:
                result = await bot.channel_preview_by_join_link(
                    identifier
                )
                return result.channel.channel_guid
            result = await bot.group_preview_by_join_link(
                identifier
            )
            return result.group.group_guid
        except Exception as error:
            raise ValueError("لینک نامعتبر است.") from error
    try:
        result = await bot.get_object_by_username(identifier)
        if hasattr(result, "user"):
            return result.user.user_guid
        if hasattr(result, "group"):
            return result.group.group_guid
        if hasattr(result, "channel"):
            return result.channel.channel_guid
    except Exception as error:
        raise ValueError("یوزرنیم یا شناسه معتبر نیست.") from error
    raise ValueError("نوع شیء شناسایی نشد.")


async def get_reply_author_guid(update):
    reply_id = getattr(update.message, "reply_to_message_id", None)
    if not reply_id:
        return None
    reply_msg = getattr(update.message, "reply_to_message", None)
    if reply_msg is None:
        reply_msg = getattr(update.message, "reply_to", None)
    if reply_msg is not None:
        author = getattr(reply_msg, "author_object_guid", None)
        if author is None:
            author = getattr(reply_msg, "author_guid", None)
        if author:
            return author
    try:
        result = await bot.get_messages_by_id(
            update.object_guid, [reply_id]
        )
        messages = getattr(result, "messages", None)
        if messages is None:
            messages = (
                result if isinstance(result, list) else [result]
            )
        if messages:
            message = messages[0]
            author = getattr(message, "author_object_guid", None)
            if author is None:
                author = getattr(message, "author_guid", None)
            if author:
                return author
    except Exception as error:
        logger.warning(
            "get_reply_author_guid failed: %s", error
        )
    return None


async def resolve_target_or_respond(update, identifier):
    target_guid = None
    if getattr(update.message, "reply_to_message_id", None):
        target_guid = await get_reply_author_guid(update)
    if target_guid is None and identifier:
        try:
            target_guid = await resolve_target_guid(identifier)
        except ValueError as error:
            spawn(respond_and_cleanup(update, f"⚠️ {error}", 10))
            return None
    if target_guid is None:
        text = (
            "❌ کاربری مشخص نشد. "
            "ریپلای کنید یا شناسه/یوزرنیم را بنویسید."
        )
        spawn(respond_and_cleanup(update, text, 10))
        return None
    return target_guid


async def admin_stop(update):
    set_bot_active(False)
    spawn(respond_and_cleanup(update, "🛑 ربات متوقف شد.", 30))


async def admin_start(update):
    set_bot_active(True)
    spawn(respond_and_cleanup(update, "✅ ربات راه‌اندازی شد.", 10))


async def set_auto_stats(update, match):
    global AUTO_STATS_ENABLED, AUTO_STATS_TIME
    global LAST_AUTO_STATS_DATE, AUTO_STATS_HANDLE
    AUTO_STATS_ENABLED = True
    AUTO_STATS_TIME = match.group(1).translate(DIGIT_TABLE)
    LAST_AUTO_STATS_DATE = ""
    if AUTO_STATS_HANDLE is not None:
        AUTO_STATS_HANDLE.cancel()
    schedule_auto_stats()
    text = f"⏰ آمار خودکار برای ساعت {AUTO_STATS_TIME} فعال شد."
    spawn(respond_and_cleanup(update, text, 15))


async def disable_auto_stats(update):
    global AUTO_STATS_ENABLED, AUTO_STATS_HANDLE
    AUTO_STATS_ENABLED = False
    if AUTO_STATS_HANDLE is not None:
        AUTO_STATS_HANDLE.cancel()
        AUTO_STATS_HANDLE = None
    text = "🛑 آمار خودکار غیرفعال شد."
    spawn(respond_and_cleanup(update, text, 15))


async def block_user(update, match):
    target_guid = await resolve_target_or_respond(
        update, match.group(1)
    )
    if target_guid is None:
        return
    if target_guid in ADMIN_GUIDS:
        spawn(
            respond_and_cleanup(
                update, "⛔ نمی‌توانید ادمین را بلاک کنید.", 10
            )
        )
        return
    was_special = target_guid in SPECIAL_USERS
    SPECIAL_USERS.discard(target_guid)
    if target_guid in BLOCKED_USERS:
        text = f"⚠️ کاربر `{target_guid}` قبلاً بلاک شده است."
        spawn(respond_and_cleanup(update, text, 10))
        return
    BLOCKED_USERS.add(target_guid)
    note = " و از لیست ویژه حذف شد" if was_special else ""
    text = f"🚫 کاربر `{target_guid}` بلاک شد{note}."
    spawn(respond_and_cleanup(update, text, 15))


async def special_user(update, match):
    target_guid = await resolve_target_or_respond(
        update, match.group(1)
    )
    if target_guid is None:
        return
    was_blocked = target_guid in BLOCKED_USERS
    BLOCKED_USERS.discard(target_guid)
    if target_guid in SPECIAL_USERS:
        text = f"⭐ کاربر `{target_guid}` قبلاً ویژه شده است."
        spawn(respond_and_cleanup(update, text, 10))
        return
    SPECIAL_USERS.add(target_guid)
    note = " و از بلاک خارج شد" if was_blocked else ""
    text = f"⭐ کاربر `{target_guid}` ویژه شد{note}."
    spawn(respond_and_cleanup(update, text, 15))


async def close_group(update):
    try:
        await bot.set_group_default_access(
            update.object_guid,
            ["ViewMembers", "ViewAdmins", "AddMember"],
        )
        text = (
            "🔒 گروه بسته شد. "
            "فقط ادمین‌ها می‌توانند پیام بفرستند."
        )
        spawn(respond_and_cleanup(update, text, 15))
    except Exception as error:
        log_error("close_group", error)
        spawn(respond_and_cleanup(update, "❌ خطا در بستن گروه.", 10))


async def open_group(update):
    try:
        await bot.set_group_default_access(
            update.object_guid,
            [
                "ViewMembers",
                "ViewAdmins",
                "SendMessages",
                "AddMember",
            ],
        )
        text = (
            "🔓 گروه باز شد. "
            "همه می‌توانند پیام بفرستند."
        )
        spawn(respond_and_cleanup(update, text, 15))
    except Exception as error:
        log_error("open_group", error)
        text = "❌ خطا در باز کردن گروه."
        spawn(respond_and_cleanup(update, text, 10))


async def add_admin(update, match):
    target_guid = await resolve_target_or_respond(
        update, match.group(1)
    )
    if target_guid is None:
        return
    if target_guid in ADMIN_GUIDS:
        text = f"⚠️ کاربر `{target_guid}` قبلاً ادمین است."
        spawn(respond_and_cleanup(update, text, 10))
        return
    ADMIN_GUIDS.add(target_guid)
    text = f"👑 کاربر `{target_guid}` به لیست ادمین‌ها اضافه شد."
    spawn(respond_and_cleanup(update, text, 15))


async def remove_admin(update, match):
    target_guid = await resolve_target_or_respond(
        update, match.group(1)
    )
    if target_guid is None:
        return
    if target_guid == MAIN_ADMIN_GUID:
        text = "⛔ نمی‌توانید ادمین اصلی را عزل کنید."
        spawn(respond_and_cleanup(update, text, 10))
        return
    if target_guid not in ADMIN_GUIDS:
        text = f"⚠️ کاربر `{target_guid}` ادمین نیست."
        spawn(respond_and_cleanup(update, text, 10))
        return
    ADMIN_GUIDS.remove(target_guid)
    text = f"❌ کاربر `{target_guid}` از لیست ادمین‌ها حذف شد."
    spawn(respond_and_cleanup(update, text, 15))


async def delete_messages_command(update, match):
    count = int(match.group(1).translate(DIGIT_TABLE))
    if count < 1:
        return
    if count > 1000:
        text = "⚠️ حداکثر ۱۰۰۰ پیام را می‌توانید حذف کنید."
        spawn(respond_and_cleanup(update, text, 10))
        return
    try:
        result = await bot.get_messages(
            update.object_guid,
            max_id="0",
            limit=str(count),
            sort="FromMax",
        )
        ids = extract_message_ids(result)[:count]
        if not ids:
            text = "📭 پیامی برای حذف یافت نشد."
            spawn(respond_and_cleanup(update, text, 10))
            return
        await bot.delete_messages(
            object_guid=update.object_guid, message_ids=ids
        )
        text = f"🧹 {len(ids)} پیام با موفقیت حذف شد."
        spawn(respond_and_cleanup(update, text, 10))
    except Exception as error:
        log_error("delete_messages_command", error)
        text = "❌ خطا در حذف پیام‌ها."
        spawn(respond_and_cleanup(update, text, 10))


async def ban_user(update, match):
    target_guid = await resolve_target_or_respond(
        update, match.group(1)
    )
    if target_guid is None:
        return
    if target_guid in ADMIN_GUIDS:
        spawn(
            respond_and_cleanup(
                update, "⛔ نمی‌توانید ادمین را بن کنید.", 10
            )
        )
        return
    try:
        await bot.ban_group_member(
            group_guid=update.object_guid,
            member_guid=target_guid,
            action="Set",
        )
        text = f"🚫 کاربر `{target_guid}` بن شد."
        spawn(respond_and_cleanup(update, text, 15))
    except Exception as error:
        log_error("ban_user", error)
        text = "❌ خطا در بن کردن کاربر."
        spawn(respond_and_cleanup(update, text, 10))


async def unban_user(update, match):
    target_guid = await resolve_target_or_respond(
        update, match.group(1)
    )
    if target_guid is None:
        return
    try:
        await bot.ban_group_member(
            group_guid=update.object_guid,
            member_guid=target_guid,
            action="Unset",
        )
        try:
            link_info = await bot.get_group_link(update.object_guid)
            invite_link = getattr(link_info, "join_link", None)
            if invite_link:
                text = (
                    "✅ شما از گروه آنبن شدید.\n"
                    f"🔗 لینک گروه:\n{invite_link}"
                )
                await send_message_safe(target_guid, text)
        except Exception as error:
            log_error("unban_get_link", error)
        text = f"🔓 کاربر `{target_guid}` از بن خارج شد."
        spawn(respond_and_cleanup(update, text, 15))
    except Exception as error:
        log_error("unban_user", error)
        text = "❌ خطا در خارج کردن کاربر از بن."
        spawn(respond_and_cleanup(update, text, 10))


def detach_game(chat_id, game):
    games = active_games.get(chat_id)
    if games is not None:
        games.pop(game["id"], None)
        if not games:
            active_games.pop(chat_id, None)
    cancel_game_timers(game)
    start_message_index.pop(game.get("start_msg_id"), None)


async def remove_game_by_id(chat_id, game_id, delete_banners=True):
    games = active_games.get(chat_id)
    if not games:
        return None
    game = games.pop(game_id, None)
    if game is None:
        return None
    cancel_game_timers(game)
    start_message_index.pop(game.get("start_msg_id"), None)
    if not games:
        active_games.pop(chat_id, None)
    if delete_banners:
        await delete_messages_safe(
            chat_id, [game.get("start_msg_id")]
        )
        forwarded = game.get("forwarded_msg_id")
        if forwarded is not None:
            await delete_messages_safe(
                TARGET_GROUP_GUID, [forwarded]
            )
    return game


async def show_stats(update):
    spawn(respond_and_cleanup(update, generate_stats_text(), 60))


async def help_handler(update):
    spawn(respond_and_cleanup(update, HELP_TEXT, 20))


async def list_games(update):
    chat_id = update.object_guid
    games = active_games.get(chat_id)
    if not games:
        spawn(
            respond_and_cleanup(update, "📭 لیست بازی‌ها خالی است.", 20)
        )
        return
    now_mono = asyncio.get_running_loop().time()
    lines = ["📋 لیست بازی‌های فعال:"]
    for game in games.values():
        start_mono = game.get("start_mono", now_mono)
        hours = (now_mono - start_mono) / 3600
        warning = " ⚠️" if hours >= WARNING_AFTER_HOURS else ""
        lines.append(
            f"🆔 شناسه بازی: `{game['id']}`{warning}\n"
            f"🎭 سناریو: {game['scenario_caption']}\n"
            f"🛠️ سازنده: {game['builder']}\n"
            f"⏰ زمان استارت: {game['start_time']}\n"
            f"⏳ مدت: {hours:.1f} ساعت\n"
            "➖➖➖➖➖➖➖➖"
        )
    spawn(respond_and_cleanup(update, "\n".join(lines), 20))


async def delete_specific_game(update, match):
    chat_id = update.object_guid
    game_id = f"{int(match.group(1).translate(DIGIT_TABLE)):02d}"
    game = await remove_game_by_id(chat_id, game_id)
    if game is None:
        text = f"🔍 بازی با شناسه `{game_id}` یافت نشد."
        spawn(respond_and_cleanup(update, text, 20))
        return
    text = f"✅ بازی `{game_id}` با موفقیت حذف شد."
    spawn(respond_and_cleanup(update, text, 20))


async def delete_all_games(update):
    chat_id = update.object_guid
    games = active_games.pop(chat_id, None)
    if not games:
        spawn(
            respond_and_cleanup(update, "📭 هیچ بازی فعالی نیست.", 20)
        )
        return
    start_ids = []
    forward_ids = []
    for game in games.values():
        cancel_game_timers(game)
        start_message_index.pop(game.get("start_msg_id"), None)
        start_id = game.get("start_msg_id")
        if start_id is not None:
            start_ids.append(start_id)
        forwarded = game.get("forwarded_msg_id")
        if forwarded is not None:
            forward_ids.append(forwarded)
    await delete_messages_safe(chat_id, start_ids)
    await delete_messages_safe(TARGET_GROUP_GUID, forward_ids)
    text = "🧹 تمامی بازی‌ها حذف شدند."
    spawn(respond_and_cleanup(update, text, 20))


async def process_start(update, match):
    chat_id = update.object_guid
    user_guid = update.author_guid
    download_task = None
    try:
        scenario_part = match.group(1).strip()
        builder_fa = match.group(2).strip()
        should_forward = match.group(3) is not None
        scenario_words = scenario_part.split()
        if any(word in DUNYTO_VARIATIONS for word in scenario_words):
            scenario_fa = " ".join(
                word
                for word in scenario_words
                if word not in DUNYTO_VARIATIONS
            ).strip()
            if scenario_fa:
                scenario_caption = f"{scenario_fa} ➪ دُنیتو"
            else:
                scenario_caption = "دُنیتو"
        else:
            scenario_caption = scenario_part
        builder_en, corrected_name = normalize_builder_name(builder_fa)
        file_inline = getattr(update.message, "file_inline", None)
        if file_inline is None:
            return
        download_task = asyncio.create_task(bot.download(file_inline))
        download_task.add_done_callback(_silent_done)
        now = get_shamsi_now()
        caption = (
            "🌱بِه نامِ خوبی راستی و پاکی 🌱\n\n"
            f"🧑‍💻سازنده دک: ✺ DoN 𖤍 {builder_en}✺\n\n"
            f"📜سناریو: {scenario_caption}\n\n"
            f"⏱︎ساعت شروع : {now}\n\n"
            "🔖برای عضویت و ارتباط با لیدر گروه:\n\n"
            "@Don55555\n\n"
            "𒆜ادب احترام میاره❥︎احترام اعتبار𒆜"
        )
        correction_note = ""
        if corrected_name:
            correction_note = (
                f"\n\n⚠️ نام '{builder_fa}' به '{corrected_name}' "
                "اصلاح شد."
            )
        file_meta = {}
        file_name = getattr(file_inline, "file_name", None)
        width = getattr(file_inline, "width", None)
        height = getattr(file_inline, "height", None)
        if file_name is not None:
            file_meta["file_name"] = file_name
        if width is not None:
            file_meta["width"] = width
        if height is not None:
            file_meta["height"] = height
        old_banner = pending_banners.get(user_guid)
        if old_banner is not None:
            handle = old_banner.pop("expire_handle", None)
            if handle is not None:
                handle.cancel()
            old_task = old_banner.get("download_task")
            if old_task is not None and not old_task.done():
                old_task.cancel()
            old_preview = old_banner.get("preview_msg_id")
            if old_preview is not None:
                pending_by_preview.pop(old_preview, None)
                spawn(
                    delete_messages_safe(
                        old_banner["chat_id"], [old_preview]
                    )
                )
        banner_data = {
            "chat_id": chat_id,
            "file_inline": file_inline,
            "download_task": download_task,
            "photo_raw": None,
            "caption": caption,
            "file_meta": file_meta,
            "should_forward": should_forward,
            "scenario_caption": scenario_caption,
            "builder_en": builder_en,
            "now": now,
            "creator_guid": user_guid,
            "builder_fa": builder_fa,
            "user_msg_id": update.message_id,
        }
        pending_banners[user_guid] = banner_data
        preview_text = (
            f"⚠️ پیش‌نمایش بنر{correction_note}\n\n{caption}\n\n"
            "آیا اطلاعات صحیح است؟\n"
            "✅ برای تایید کلمه بله را ریپلای کنید.\n"
            "❌ برای رد کردن کلمه نه را ریپلای کنید."
        )
        preview_msg = await bot.send_message(
            object_guid=chat_id,
            text=preview_text,
            reply_to_message_id=update.message_id,
        )
        preview_msg_id = getattr(preview_msg, "message_id", None)
        if preview_msg_id is None:
            preview_msg_id = extract_message_id(preview_msg)
        if preview_msg_id is None:
            pending_banners.pop(user_guid, None)
            if not download_task.done():
                download_task.cancel()
            return
        banner_data["preview_msg_id"] = preview_msg_id
        pending_by_preview[preview_msg_id] = user_guid
        banner_data["expire_handle"] = (
            asyncio.get_running_loop().call_later(
                PENDING_EXPIRE_SECONDS,
                expire_pending,
                user_guid,
                preview_msg_id,
            )
        )
    except Exception as error:
        if download_task is not None and not download_task.done():
            download_task.cancel()
        pending_banners.pop(user_guid, None)
        log_error("process_start", error)


async def confirm_banner(update, banner, preview_msg_id):
    raw = banner.get("photo_raw")
    if raw is None:
        task = banner.get("download_task")
        if task is not None:
            raw = await task
            banner["photo_raw"] = raw
        else:
            raw = await bot.download(banner["file_inline"])
    sent = await bot.send_photo(
        object_guid=banner["chat_id"],
        photo=raw,
        caption=banner["caption"],
        **banner["file_meta"],
    )
    sent_msg_id = getattr(sent, "message_id", None)
    if sent_msg_id is None:
        sent_msg_id = extract_message_id(sent)
    chat_id = banner["chat_id"]
    games = active_games.setdefault(chat_id, {})
    game_id = find_available_game_id(games)
    loop = asyncio.get_running_loop()
    game = {
        "id": game_id,
        "start_msg_id": sent_msg_id,
        "scenario_caption": banner["scenario_caption"],
        "builder": banner["builder_en"],
        "should_forward": banner["should_forward"],
        "start_time": banner["now"],
        "start_mono": loop.time(),
        "forwarded_msg_id": None,
        "timeout_warned": False,
        "closing": False,
    }
    games[game_id] = game
    if sent_msg_id is not None:
        start_message_index[sent_msg_id] = (chat_id, game_id)
    game["warn_handle"] = loop.call_later(
        WARNING_AFTER_HOURS * 3600,
        _game_warning,
        chat_id,
        game_id,
    )
    game["close_handle"] = loop.call_later(
        AUTO_CLOSE_AFTER_HOURS * 3600,
        _game_close,
        chat_id,
        game_id,
    )
    update_stats(banner["builder_en"], banner["scenario_caption"])
    if banner["should_forward"] and sent_msg_id is not None:
        get_forward_queue().put_nowait(
            {
                "from_guid": chat_id,
                "message_id": sent_msg_id,
                "chat_id": chat_id,
                "game_id": game_id,
            }
        )
    await delete_messages_safe(
        chat_id,
        [
            preview_msg_id,
            banner.get("user_msg_id"),
            update.message_id,
        ],
    )


async def reject_banner(update, banner, preview_msg_id):
    text = "♻️ بنر رد شد. لطفاً نسخه صحیح را مجدداً ارسال کنید."
    await send_message_safe(
        banner["chat_id"], text, update.message_id, 15
    )
    await delete_messages_safe(
        banner["chat_id"],
        [
            preview_msg_id,
            banner.get("user_msg_id"),
            update.message_id,
        ],
    )


async def process_confirmation(update, reply_id, word):
    target_user_guid = pending_by_preview.get(reply_id)
    if target_user_guid is None:
        return
    if update.author_guid != target_user_guid:
        text = (
            "❌ فقط ارسال‌کننده اصلی بنر "
            "می‌تواند آن را تأیید یا رد کند."
        )
        spawn(respond_and_cleanup(update, text, 10))
        return
    if reply_id in processing_previews:
        return
    processing_previews.add(reply_id)
    banner = None
    try:
        banner = pending_banners.get(target_user_guid)
        if banner is None or banner.get("preview_msg_id") != reply_id:
            return
        handle = banner.get("expire_handle")
        if handle is not None:
            handle.cancel()
        if word in CONFIRM_WORDS:
            await confirm_banner(update, banner, reply_id)
        else:
            task = banner.get("download_task")
            if task is not None and not task.done():
                task.cancel()
            await reject_banner(update, banner, reply_id)
        pending_banners.pop(target_user_guid, None)
        pending_by_preview.pop(reply_id, None)
    except Exception as error:
        pending_banners.pop(target_user_guid, None)
        pending_by_preview.pop(reply_id, None)
        if banner is not None:
            task = banner.get("download_task")
            if task is not None and not task.done():
                task.cancel()
        log_error("process_confirmation", error)
        spawn(respond_and_cleanup(update, "❌ خطا در پردازش بنر.", 10))
    finally:
        processing_previews.discard(reply_id)


async def process_end(update, match):
    chat_id = update.object_guid
    reply_id = getattr(update.message, "reply_to_message_id", None)
    try:
        winner = match.group(1).strip()
        should_forward = match.group(2) is not None
        games = active_games.get(chat_id)
        if not games:
            spawn(
                respond_and_cleanup(
                    update, "📭 بازی فعالی ثبت نشده است.", 15
                )
            )
            return
        game = None
        if reply_id:
            indexed = start_message_index.get(reply_id)
            if indexed is not None and indexed[0] == chat_id:
                game = games.get(indexed[1])
            if game is None:
                game = next(
                    (
                        item
                        for item in games.values()
                        if item.get("start_msg_id") == reply_id
                    ),
                    None,
                )
        if game is None and reply_id is None:
            game = next(iter(games.values()), None)
        if game is None:
            text = "🔍 بازی مرتبط با این ریپلای یافت نشد."
            spawn(respond_and_cleanup(update, text, 15))
            return
        file_inline = getattr(update.message, "file_inline", None)
        if file_inline is None:
            return
        raw = await bot.download(file_inline)
        now = get_shamsi_now()
        caption = (
            "🏆🏆🏆🏆🏆🏆🏆🏆\n\n"
            f"🎞سناریو: {game['scenario_caption']}\n\n"
            f"🧑‍💻سازنده لابی: ✺DσN 𖤍 {game['builder']}✺\n\n"
            f"🥇برنده : {winner} ➪ 🏆\n\n"
            f"⏱︎ساعت پایان : {now}\n\n"
            "مافیا های زندگیت رو بشناس 🔥🔥🔥\n\n"
            "🔖عضویت و ارتباط با لیدر گروه:\n\n@DoN55555\n\n"
            "𒆜ادب احترام میاره❥︎احترام اعتبار𒆜"
        )
        file_meta = {}
        file_name = getattr(file_inline, "file_name", None)
        width = getattr(file_inline, "width", None)
        height = getattr(file_inline, "height", None)
        if file_name is not None:
            file_meta["file_name"] = file_name
        if width is not None:
            file_meta["width"] = width
        if height is not None:
            file_meta["height"] = height
        sent_end = await bot.send_photo(
            object_guid=chat_id,
            photo=raw,
            caption=caption,
            reply_to_message_id=game.get("start_msg_id"),
            **file_meta,
        )
        sent_end_id = getattr(sent_end, "message_id", None)
        if sent_end_id is None:
            sent_end_id = extract_message_id(sent_end)
        detach_game(chat_id, game)
        await delete_messages_safe(chat_id, [update.message_id])
        if should_forward and sent_end_id is not None:
            get_forward_queue().put_nowait(
                {"from_guid": chat_id, "message_id": sent_end_id}
            )
    except Exception as error:
        log_error("process_end", error)


@bot.on_message_updates(MAIN_GROUP_FILTER, filters.photo)
async def handle_photo(update):
    if update.object_guid != MAIN_GROUP_GUID:
    	return
    if not consume_message_id(update.message_id):
        return
    if not is_user_allowed(update):
        return
    text = getattr(update.message, "text", None) or ""
    text = text.translate(NORMALIZE_TABLE).strip()
    if not text:
        return
    match = START_REGEX.match(text)
    if match:
        await process_start(update, match)
        return
    match = END_REGEX.match(text)
    if match:
        await process_end(update, match)


@bot.on_message_updates(MAIN_GROUP_FILTER, filters.text)
async def handle_text(update):
    if update.object_guid != MAIN_GROUP_GUID:
    	return
    if getattr(update.message, "file_inline", None) is not None:
        return
    if not consume_message_id(update.message_id):
        return
    text = getattr(update.message, "text", None) or ""
    text = text.strip()
    if not text:
        return
    normalized = normalize_text(text)
    if not normalized:
        return
    word = first_word(normalized)
    if not word:
        return
    reply_id = getattr(update.message, "reply_to_message_id", None)
    if reply_id and (word in CONFIRM_WORDS or word in REJECT_WORDS):
        if is_user_allowed(update):
            await process_confirmation(update, reply_id, word)
        return
    author = update.author_guid
    if author == MAIN_ADMIN_GUID:
        if STOP_REGEX.match(normalized):
            await admin_stop(update)
            return
        if BOT_START_REGEX.match(normalized):
            await admin_start(update)
            return
    if author in ADMIN_GUIDS:
        match = AUTO_STATS_SET_REGEX.match(normalized)
        if match:
            await set_auto_stats(update, match)
            return
        if AUTO_STATS_DISABLE_REGEX.match(normalized):
            await disable_auto_stats(update)
            return
        if CLOSE_GROUP_REGEX.match(normalized):
            await close_group(update)
            return
        if OPEN_GROUP_REGEX.match(normalized):
            await open_group(update)
            return
        match = DELETE_MESSAGES_REGEX.match(normalized)
        if match:
            await delete_messages_command(update, match)
            return
    if author == MAIN_ADMIN_GUID:
        match = ADD_ADMIN_REGEX.match(normalized)
        if match:
            await add_admin(update, match)
            return
        match = REMOVE_ADMIN_REGEX.match(normalized)
        if match:
            await remove_admin(update, match)
            return
    if not is_user_allowed(update):
        return
    if word in STATS_WORDS:
        await show_stats(update)
        return
    if word in HELP_WORDS:
        await help_handler(update)
        return
    if LIST_GAMES_REGEX.match(normalized):
        await list_games(update)
        return
    match = DELETE_ALL_REGEX.match(normalized)
    if match:
        await delete_all_games(update)
        return
    match = DELETE_GAME_REGEX.match(normalized)
    if match:
        await delete_specific_game(update, match)
        return
    if author in ADMIN_GUIDS:
        match = BLOCK_REGEX.match(normalized)
        if match:
            await block_user(update, match)
            return
        match = SPECIAL_REGEX.match(normalized)
        if match:
            await special_user(update, match)
            return
        match = BAN_REGEX.match(normalized)
        if match:
            await ban_user(update, match)
            return
        match = UNBAN_REGEX.match(normalized)
        if match:
            await unban_user(update, match)


if __name__ == "__main__":
    uvloop.install()
    try:
        loop = asyncio.get_event_loop()
    except RuntimeError:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
    logger.info("ربات دُنیتو راه‌اندازی شد")
    logger.info(
        "وضعیت اولیه: %s", "فعال" if IS_BOT_ACTIVE else "متوقف"
    )
    logger.info("شناسه ادمین اصلی: %s", MAIN_ADMIN_GUID)
    try:
        bot.run()
    except KeyboardInterrupt:
        logger.info("ربات توسط کاربر متوقف شد.")
    except Exception:
        logger.exception("خطای مرگبار")
    finally:
        try:
            if hasattr(bot, "disconnect"):
                loop.run_until_complete(bot.disconnect())
            elif hasattr(bot, "close"):
                loop.run_until_complete(bot.close())
        except Exception:
            pass