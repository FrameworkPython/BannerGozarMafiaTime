import re
import logging
import traceback
from collections import deque
import jdatetime
from rubpy import Client, filters
from rubpy.types import Update

LOG_FORMAT = "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s"
DATE_FORMAT = "%Y-%m-%d %H:%M:%S"

console_handler = logging.StreamHandler()
console_handler.setLevel(logging.DEBUG)
console_handler.setFormatter(logging.Formatter(LOG_FORMAT, datefmt=DATE_FORMAT))

logger = logging.getLogger('DonitoBot')
logger.setLevel(logging.DEBUG)
logger.addHandler(console_handler)
logger.propagate = False

TARGET_GROUP_GUID = "g0DHpOn042b93c4982b5b135365c7bb6"
MAIN_GROUP_GUID = "g0E19S900dd50643ab8fcbf23dad9e70"

NAME_MAP = {
    "فایتر": "Fighter", "اهورا": "Ahoora", "سبحان": "Geshtapo",
    "صبحان": "Geshtapo", "یکتا": "Yekta", "ساره": "Sareh",
    "مجی": "Moji", "گاد فادر": "GodFather", "گادفادر": "GodFather",
    "فرید": "Farid", "هانتر": "Hunter", "هانی": "Hani",
    "ماتادور": "Matador", "نیلوفر": "Niloofar", "هانیه": "Hanieh",
    "رضا": "Reza", "آتنا": "Atena", "اتنا": "Atena",
}

SCENARIO_PATTERN = r"جک|مذاکره|بازپرس|تفنگدار|پدرخوانده|فکت|شرلوک|قاتل"
START_REGEX = re.compile(rf"^({SCENARIO_PATTERN})\s+(.+?)(\s+فور)?$")
END_REGEX = re.compile(r"^پایان\s+(.+?)(\s+فور)?$")

HELP_TEXT = (
    "راهنمای ربات بنرگذار دُنیتو\n\n"
    "درود بر گاد ۲ های عزیز! 🙌\n"
    "این ربات برای ساخت و ارسال خودکار بنر بازی‌ها طراحی شده. لطفاً فقط گاد ۲ ها از آن استفاده کنند تا نظم کار حفظ شود.\n\n"
    "---\n\n"
    "📌 شرایط اولیه\n"
    "• بنر باید یک عکس داشته باشد.\n"
    "• کپشن عکس شامل دو بخش اجباری و یک بخش اختیاری (فور) است.\n"
    "• قالب شروع:\n"
    "[سناریو] [سازنده] [فور]\n\n"
    "---\n\n"
    "۱. سناریو\n"
    "نام سناریوی بازی (مثلاً بازپرس، مذاکره، فکت، شرلوک، قاتل و …)\n\n"
    "۲. سازنده دک\n"
    "نام سازنده را از میان موارد زیر انتخاب کنید:\n\n"
    "• فایتر\n• اهورا\n• ساره\n• مجی\n• سبحان / صبحان\n• گاد فادر / گادفادر\n• یکتا\n• هانی\n• ماتادور\n• فرید\n• نیلوفر\n• هانیه\n• هانتر\n\n"
    "اگر نامی جا افتاده، به ما اطلاع دهید تا اضافه شود.\n\n"
    "۳. فور (اختیاری)\n"
    "با اضافه کردن کلمه «فور»، ربات بنر را علاوه بر گروه اصلی، به گروه رسمی دُنیتو فوروارد می‌کند.\n\n"
    "---\n\n"
    "مثال شروع\n\n"
    "با فوروارد:\nبازپرس هانتر فور\n"
    "بدون فوروارد:\nمذاکره سبحان\n\n"
    "---\n\n"
    "پایان بازی\n"
    "برای بستن بازی، عکس پایان را با کپشن زیر بفرستید:\nپایان [برنده] [فور]\n\n"
    "• برنده: هر عبارتی که وارد کنید دقیقاً در بنر قرار می‌گیرد (مثلاً شهر، مافیا، زودیاک).\n"
    "• فور: مانند قبل، اختیاری است.\n\n"
    "مثال‌ها:\nپایان شهر فور → برنده: شهر + فوروارد\nپایان مافیا → برنده: مافیا، بدون فوروارد\n\n"
    "---\n\n"
    "نکات مهم\n"
    "• برای پایان بازی نیازی به ریپلای روی بنر شروع نیست؛ ربات خودکار اولین بازی آغازشده را می‌بندد.\n"
    "• اگر چند بازی همزمان فعال دارید، اولویت پایان با بازی‌ای است که زودتر شروع شده.\n"
    "• حتماً یک عکس همراه کپشن باشد، در غیر این‌صورت ربات اقدامی نمی‌کند.\n"
    "• پردازش عکس ممکن است چند لحظه زمان ببرد.\n\n"
    "با آرزوی بازی‌های پرهیجان و منظم برای شما ✨"
)

active_games = {}

def persian_to_finglish(text: str) -> str:
    mapping = {
        'ا': 'a', 'آ': 'a', 'ب': 'b', 'پ': 'p', 'ت': 't', 'ث': 's',
        'ج': 'j', 'چ': 'ch', 'ح': 'h', 'خ': 'kh', 'د': 'd',
        'ذ': 'z', 'ر': 'r', 'ز': 'z', 'ژ': 'zh', 'س': 's',
        'ش': 'sh', 'ص': 's', 'ض': 'z', 'ط': 't', 'ظ': 'z',
        'ع': 'a', 'غ': 'gh', 'ف': 'f', 'ق': 'gh', 'ک': 'k',
        'گ': 'g', 'ل': 'l', 'م': 'm', 'ن': 'n', 'و': 'v',
        'ه': 'h', 'ی': 'y', 'ي': 'i', 'ئ': 'e',
        ' ': ' ', '؟': '?', '،': ',', '؛': ';',
        '۰': '0', '۱': '1', '۲': '2', '۳': '3', '۴': '4',
        '۵': '5', '۶': '6', '۷': '7', '۸': '8', '۹': '9',
        'َ': 'a', 'ُ': 'o', 'ِ': 'e',
    }
    return ''.join(mapping.get(ch, ch) for ch in text).title().replace(' ', '')

def normalize_builder_name(raw: str) -> str:
    key = ' '.join(raw.split())
    return NAME_MAP.get(key, persian_to_finglish(key))

def get_shamsi_now() -> str:
    return jdatetime.datetime.now().strftime("%Y/%m/%d - %H:%M")

def log_error(context: str, error: Exception) -> None:
    logger.error(f"{context} | نوع خطا: {type(error).__name__} | پیام: {error}")
    logger.debug(traceback.format_exc())

def find_available_game_id(chat_id: str) -> str:
    games = active_games[chat_id]['games']
    used = {g['id'] for g in games}
    for i in range(1, 100):
        candidate = f"{i:02d}"
        if candidate not in used:
            return candidate
    return "XX"

bot = Client("bot")

@bot.on_message_updates(
    filters.object_guid(MAIN_GROUP_GUID),
    filters.photo,
    filters.regex(START_REGEX),
)
async def handle_start(update: Update):
    chat_id = update.object_guid
    user_msg_id = update.message_id
    logger.info(f"شروع بازی | {update.author_guid} | {update.message.text[:50]}")
    try:
        match = START_REGEX.search(update.message.text)
        if not match:
            return
        scenario_fa = match.group(1)
        builder_fa = match.group(2)
        builder_en = normalize_builder_name(builder_fa)
        should_forward = match.group(3) is not None
        raw = await bot.download(update.message.file_inline)
        now = get_shamsi_now()
        caption = (
            "🌱بِه نامِ خوبی راستی و پاکی 🌱\n\n"
            f"🧑‍💻سازنده دک :  ✺ DoN 𖤍 {builder_en}✺\n\n"
            f"📜سناریو: {scenario_fa} ➪ دُنیتو\n\n"
            f"⏱︎ساعت شروع : {now}\n\n"
            "🔖برای عضویت و ارتباط با لیدر گروه:\n\n"
            "@Don55555\n\n"
            "𒆜ادب احترام میاره❥︎احترام اعتبار𒆜"
        )
        sent = await bot.send_photo(
            object_guid=chat_id, photo=raw, caption=caption,
            file_name=update.message.file_inline.file_name,
            width=update.message.file_inline.width,
            height=update.message.file_inline.height,
        )
        logger.info(f"بنر شروع ارسال شد {sent.message_id}")
        if chat_id not in active_games:
            active_games[chat_id] = {'games': deque()}
        game_id = find_available_game_id(chat_id)
        game = {
            "id": game_id, "start_msg_id": sent.message_id,
            "scenario": scenario_fa, "builder": builder_en,
            "should_forward": should_forward, "start_time": now,
            "forwarded_msg_id": None,
        }
        if should_forward:
            try:
                fwd = await bot.forward_messages(
                    from_object_guid=chat_id, message_ids=sent.message_id,
                    to_object_guid=TARGET_GROUP_GUID,
                )
                game['forwarded_msg_id'] = fwd[0].message_id if isinstance(fwd, list) else fwd.message_id
            except Exception as e:
                log_error("فوروارد شروع", e)
        active_games[chat_id]['games'].append(game)
        logger.info(f"بازی جدید {game_id} | تعداد: {len(active_games[chat_id]['games'])}")
        await bot.delete_messages(object_guid=chat_id, message_ids=user_msg_id)
    except Exception as e:
        log_error("handle_start", e)

@bot.on_message_updates(
    filters.object_guid(MAIN_GROUP_GUID),
    filters.photo,
    filters.regex(END_REGEX),
)
async def handle_end(update: Update):
    chat_id = update.object_guid
    user_msg_id = update.message_id
    reply_id = update.message.reply_to_message_id
    logger.info(f"پایان بازی | reply_id={reply_id} | {update.message.text[:50]}")
    try:
        if chat_id not in active_games or not active_games[chat_id]['games']:
            return
        games = active_games[chat_id]['games']
        if reply_id:
            game = next((g for g in games if g["start_msg_id"] == reply_id), None)
            if game is None:
                return
            games.remove(game)
        else:
            game = games.popleft()
        match = END_REGEX.search(update.message.text)
        if not match:
            return
        winner = match.group(1)
        should_forward = match.group(2) is not None
        raw_bytes = await bot.download(update.message.file_inline)
        now = get_shamsi_now()
        caption = (
            "🏆🏆🏆🏆🏆🏆🏆🏆🏆🏆🏆\n\n"
            f"🎞سناریو:    {game['scenario']}  ➪  دُنیتو\n\n"
            f"🧑‍💻سازنده لابی: ✺DσN 𖤍 {game['builder']}✺\n\n"
            f"🥇برنده : {winner}  ➪ 🏆\n\n"
            f"⏱︎ساعت پایان : {now}\n\n"
            "مافیا های زندگیت رو بشناس 🔥🔥🔥\n\n"
            "🔖عضویت و ارتباط با لیدر گروه:\n\n"
            "@DoN55555\n\n"
            "𒆜ادب احترام میاره❥︎احترام اعتبار𒆜"
        )
        sent_end = await bot.send_photo(
            object_guid=chat_id, photo=raw_bytes, caption=caption,
            file_name=update.message.file_inline.file_name,
            width=update.message.file_inline.width,
            height=update.message.file_inline.height,
            reply_to_message_id=game["start_msg_id"],
        )
        logger.info(f"بنر پایان ارسال شد {sent_end.message_id}")
        await bot.delete_messages(object_guid=chat_id, message_ids=user_msg_id)
        if should_forward:
            try:
                await bot.forward_messages(
                    from_object_guid=chat_id, message_ids=sent_end.message_id,
                    to_object_guid=TARGET_GROUP_GUID,
                )
            except Exception as e:
                log_error("فوروارد پایان", e)
    except Exception as e:
        log_error("handle_end", e)

@bot.on_message_updates(
    filters.object_guid(MAIN_GROUP_GUID),
    filters.text,
    filters.regex(r"^راهنما$"),
)
async def help_handler(update: Update):
    logger.info("درخواست راهنما")
    await bot.send_message(
        object_guid=update.object_guid,
        text=HELP_TEXT,
        reply_to_message_id=update.message_id,
        auto_delete=20,
    )
    await bot.delete_messages(object_guid=update.object_guid, message_ids=update.message_id)

@bot.on_message_updates(
    filters.object_guid(MAIN_GROUP_GUID),
    filters.text,
)
async def list_games(update: Update):
    chat_id = update.object_guid
    user_msg_id = update.message_id
    text = update.message.text.strip()
    if not re.search(r"^لیست\s*بازی[\s\u200c]*(?:ها)?$", text):
        return
    logger.info("لیست بازی‌ها")
    try:
        if chat_id not in active_games or not active_games[chat_id]['games']:
            reply = "📭 لیست بازی‌ها خالی است."
        else:
            lines = ["📋 **لیست بازی‌های فعال:**\n"]
            for g in active_games[chat_id]['games']:
                lines.append(
                    f"🆔 شناسه بازی: `{g['id']}`\n"
                    f"🎭 سناریو: {g['scenario']}\n"
                    f"🛠️ سازنده: {g['builder']}\n"
                    f"⏰ زمان استارت: {g['start_time']}\n"
                    "➖➖➖➖➖➖➖➖➖➖"
                )
            reply = "\n".join(lines)
        await bot.send_message(
            object_guid=chat_id, text=reply,
            reply_to_message_id=user_msg_id, auto_delete=20,
        )
        await bot.delete_messages(object_guid=chat_id, message_ids=user_msg_id)
    except Exception as e:
        log_error("list_games", e)

@bot.on_message_updates(
    filters.object_guid(MAIN_GROUP_GUID),
    filters.text,
)
async def delete_specific_game(update: Update):
    chat_id = update.object_guid
    user_msg_id = update.message_id
    text = update.message.text.strip()
    match = re.search(r"^حذف\s*بازی\s*(\d+)$", text)
    if not match:
        return
    target_id = f"{int(match.group(1)):02d}"
    logger.info(f"حذف بازی {target_id}")
    try:
        if chat_id not in active_games or not active_games[chat_id]['games']:
            await bot.send_message(object_guid=chat_id, text="❌ بازی‌ای وجود ندارد", reply_to_message_id=user_msg_id, auto_delete=20)
            await bot.delete_messages(object_guid=chat_id, message_ids=user_msg_id)
            return
        games = active_games[chat_id]['games']
        game_to_remove = None
        remaining = deque()
        for g in games:
            if g['id'] == target_id:
                game_to_remove = g
            else:
                remaining.append(g)
        if game_to_remove is None:
            await bot.send_message(object_guid=chat_id, text=f"🔍 بازی {target_id} یافت نشد", reply_to_message_id=user_msg_id, auto_delete=20)
        else:
            active_games[chat_id]['games'] = remaining
            try:
                await bot.delete_messages(object_guid=chat_id, message_ids=game_to_remove['start_msg_id'])
            except Exception as e:
                log_error("حذف بنر اصلی", e)
            if game_to_remove['should_forward'] and game_to_remove['forwarded_msg_id']:
                try:
                    await bot.delete_messages(object_guid=TARGET_GROUP_GUID, message_ids=game_to_remove['forwarded_msg_id'])
                except Exception as e:
                    log_error("حذف بنر فوروارد", e)
            await bot.send_message(object_guid=chat_id, text=f"✅ بازی {target_id} حذف شد", reply_to_message_id=user_msg_id, auto_delete=20)
        await bot.delete_messages(object_guid=chat_id, message_ids=user_msg_id)
    except Exception as e:
        log_error("delete_specific_game", e)

@bot.on_message_updates(
    filters.object_guid(MAIN_GROUP_GUID),
    filters.text,
)
async def delete_all_games(update: Update):
    chat_id = update.object_guid
    user_msg_id = update.message_id
    text = update.message.text.strip()
    if not re.search(r"^حذف[\s\u200c]+(?:تمام(?:ی)?[\s\u200c]+)?بازی[\s\u200c]*ها$", text):
        return
    logger.info("حذف تمام بازی‌ها")
    try:
        if chat_id not in active_games or not active_games[chat_id]['games']:
            await bot.send_message(object_guid=chat_id, text="📭 هیچ بازی فعالی نیست", reply_to_message_id=user_msg_id, auto_delete=20)
            await bot.delete_messages(object_guid=chat_id, message_ids=user_msg_id)
            return
        games = active_games[chat_id]['games']
        for g in games:
            try:
                await bot.delete_messages(object_guid=chat_id, message_ids=g['start_msg_id'])
            except Exception as e:
                log_error(f"حذف بنر {g['id']}", e)
            if g['should_forward'] and g['forwarded_msg_id']:
                try:
                    await bot.delete_messages(object_guid=TARGET_GROUP_GUID, message_ids=g['forwarded_msg_id'])
                except Exception as e:
                    log_error(f"حذف فوروارد {g['id']}", e)
        active_games[chat_id]['games'].clear()
        await bot.send_message(object_guid=chat_id, text="🧹 تمامی بازی‌ها حذف شدند", reply_to_message_id=user_msg_id, auto_delete=20)
        await bot.delete_messages(object_guid=chat_id, message_ids=user_msg_id)
    except Exception as e:
        log_error("delete_all_games", e)

if __name__ == "__main__":
    logger.info("ربات دُنیتو راه‌اندازی شد")
    try:
        bot.run()
    except Exception as e:
        logger.critical(f"خطای مرگبار: {e}")
        traceback.print_exc()