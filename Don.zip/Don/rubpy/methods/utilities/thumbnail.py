import tempfile
import warnings
import base64
import typing
import io
import os

try:
    from moviepy.editor import VideoFileClip
except (ImportError, RuntimeError):
    VideoFileClip = None

try:
    import cv2
    import numpy as np
except ImportError:
    cv2 = None
    np = None

try:
    import PIL.Image
except ImportError:
    PIL = None


class ResultMedia:
    def __repr__(self) -> str:
        return repr(vars(self))

    def __init__(
        self,
        image: bytes,
        width: int = 200,
        height: int = 200,
        seconds: int = 1,
    ) -> None:
        self.image = image
        self.width = width
        self.height = height
        self.seconds = seconds

    def to_base64(self) -> str:
        return base64.b64encode(self.image).decode("utf-8")


class MediaThumbnail:
    @classmethod
    def from_image(cls, image: bytes) -> typing.Optional[ResultMedia]:
        if PIL is not None:
            try:
                img = PIL.Image.open(io.BytesIO(image))

                width, height = img.size

                if img.mode not in ("RGB", "L"):
                    img = img.convert("RGB")

                img.thumbnail((64, 64))

                output = io.BytesIO()

                img.save(
                    output,
                    format="JPEG",
                    quality=50,
                    optimize=True,
                )

                return ResultMedia(
                    output.getvalue(),
                    width=width,
                    height=height,
                )

            except Exception as e:
                print(f"Thumbnail PIL error: {e}")

        if cv2 is None or np is None:
            warnings.warn(
                "OpenCV or NumPy not found, image processing disabled"
            )
            return None

        try:
            image_array = np.frombuffer(
                image,
                dtype=np.uint8,
            )

            image_array = cv2.imdecode(
                image_array,
                cv2.IMREAD_COLOR,
            )

            if image_array is None:
                return None

            height, width = image_array.shape[:2]

            image_array = cv2.resize(
                image_array,
                (64, 64),
                interpolation=cv2.INTER_AREA,
            )

            success, buffer = cv2.imencode(
                ".jpg",
                image_array,
                [cv2.IMWRITE_JPEG_QUALITY, 50],
            )

            if not success:
                return None

            return ResultMedia(
                bytes(buffer),
                width=width,
                height=height,
            )

        except Exception as e:
            print(f"Thumbnail OpenCV error: {e}")
            return None

    @classmethod
    def from_video(
        cls,
        video: bytes,
    ) -> typing.Optional[ResultMedia]:
        if VideoFileClip is not None:
            file_name = None

            try:
                with tempfile.NamedTemporaryFile(
                    mode="wb+",
                    suffix=".mp4",
                    delete=False,
                ) as file:
                    file.write(video)
                    file_name = file.name

                capture = VideoFileClip(file_name)

                width, height = capture.size
                seconds = int(capture.duration)

                image = capture.get_frame(
                    max(seconds // 2, 0)
                )

                capture.close()

                if file_name and os.path.exists(file_name):
                    os.remove(file_name)

                return ResultMedia(
                    image,
                    width,
                    height,
                    seconds * 1000,
                )

            except Exception as e:
                print(f"Error processing video with moviepy: {e}")

                if file_name and os.path.exists(file_name):
                    os.remove(file_name)

                return None

        if cv2 is None:
            warnings.warn(
                "OpenCV not found, video processing disabled"
            )
            return None

        with tempfile.NamedTemporaryFile(
            mode="wb+",
            suffix=".mp4",
        ) as file:
            file.write(video)

            capture = cv2.VideoCapture(file.name)

            total_frames = int(
                capture.get(cv2.CAP_PROP_FRAME_COUNT)
            )

            middle_frame = total_frames // 2

            capture.set(
                cv2.CAP_PROP_POS_FRAMES,
                middle_frame,
            )

            status, image = capture.read()

            if status:
                fps = capture.get(cv2.CAP_PROP_FPS) or 1

                seconds = int(
                    total_frames / fps
                ) * 1000

                width = image.shape[1]
                height = image.shape[0]

                return ResultMedia(
                    image,
                    width,
                    height,
                    seconds,
                )

        return None